package space.korolev.quiz;



public class Array{
    //массив для первого урованя - начало
    Number MyOne = new Number (R.drawable.onelevel_one,1,R.drawable.threelevel_one);
    /*
    Number[] MyNumbers = {
            new Number(R.drawable.onelevel_null,0),
            new Number(R.drawable.onelevel_one,1),
            new Number(R.drawable.onelevel_two,2),
            new Number(R.drawable.onelevel_three,3),
            new Number(R.drawable.onelevel_four,4),
            new Number(R.drawable.onelevel_five,5),
            new Number(R.drawable.onelevel_six,6),
            new Number(R.drawable.onelevel_seven,7),
            new Number(R.drawable.onelevel_eight,8),
            new Number(R.drawable.onelevel_nine,9),
    };*/
    final int[] images1 = {
            R.drawable.onelevel_null,
            R.drawable.onelevel_one,
            R.drawable.onelevel_two,
            R.drawable.onelevel_three,
            R.drawable.onelevel_four,
            R.drawable.onelevel_five,
            R.drawable.onelevel_six,
            R.drawable.onelevel_seven,
            R.drawable.onelevel_eight,
            R.drawable.onelevel_nine
            };
    //массив для первого урованя - начало

      final int[] texts1 = {
          R.string.num0,
          R.string.num1,
          R.string.num2,
          R.string.num3,
          R.string.num4,
          R.string.num5,
          R.string.num6,
          R.string.num7,
          R.string.num8,
          R.string.num9
  };
    //массив для первого урованя - конец

    //массив для 2 урованя - начало
    final int[] images2 = {
            R.drawable.twolevel_3,
            R.drawable.twolevel_7,
            R.drawable.twolevel_9,
            R.drawable.twolevel_10,
            R.drawable.twolevel_11,
            R.drawable.twolevel_12,
            R.drawable.twolevel_13,
            R.drawable.twolevel_14,
            R.drawable.twolevel_15,
            R.drawable.twolevel_32
    };
    //массив для 2 урованя - конец

    //массив для 3 урованя - начало
    final int[] images3 = {
            R.drawable.onelevel_null,
            R.drawable.onelevel_one,
            R.drawable.onelevel_two,
            R.drawable.onelevel_three,
            R.drawable.onelevel_four,
            R.drawable.onelevel_five,
            R.drawable.onelevel_six,
            R.drawable.onelevel_seven,
            R.drawable.onelevel_eight,
            R.drawable.onelevel_nine,
            R.drawable.threelevel_one,
            R.drawable.threelevel_two,
            R.drawable.threelevel_three,
            R.drawable.threelevel_four,
            R.drawable.threelevel_five,
            R.drawable.threelevel_six,
            R.drawable.threelevel_seven,
            R.drawable.threelevel_eight,
            R.drawable.threelevel_nine,
            R.drawable.threelevel_ten
    };

    final int[] power3 = {
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
            1, 2, 3, 4, 5, 6, 7, 8, 9, 10
    };
    //массив для 3 урованя - начало


}
